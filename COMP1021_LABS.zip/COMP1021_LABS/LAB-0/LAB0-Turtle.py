import turtle

turtle.write("Hello World!")

turtle.up()

turtle.goto(-100, 50)
turtle.right(90)

turtle.down()

turtle.forward(100)
turtle.left(90)

turtle.forward(255)
turtle.left(90)

turtle.forward(100)
turtle.left(90)

turtle.forward(255)

turtle.done()
