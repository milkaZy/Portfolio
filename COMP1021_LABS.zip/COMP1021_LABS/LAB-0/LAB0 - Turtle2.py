import turtle
import random

#Number Of Loops
num_of_loops = 0

#Rectangle Variables:
randomX = random.randint(-300,300)
randomY = random.randint(-300,300)

random_width = random.randint(30,200)
random_height = random.randint(10,150)

random_angle = random.randint(0,360)

color = ["Royal Blue", "Pale Green", "Gold", "Rosy Brown", "Coral", "Orchid"]
pen_width = random.randint(1,10)
random_colorR = random.choice(color)

#Circle Variables:
radius = random.randint(5,100)
circle_color = ["Royal Blue", "Pale Green", "Gold", "Rosy Brown", "Coral", "Orchid"]
random_colorC = random.choice(circle_color)
circle_line_width = random.randint(1,10)

#========================================================================

while num_of_loops < 5:

#Rectangle Program
    turtle.color(random_colorR, random_colorR)
    turtle.pensize( pen_width )
    turtle.begin_fill()

    turtle.up()

    turtle.goto(randomX, randomY)
    turtle.right(random_angle)

    turtle.down()

    turtle.forward(random_height)
    turtle.left(90)

    turtle.forward(random_width)
    turtle.left(90)

    turtle.forward(random_height)
    turtle.left(90)

    turtle.forward(random_width)

    turtle.end_fill()


    #Circle Placement
    turtle.up()
    turtle.goto(randomX, randomY)
    turtle.forward(random_height)
    turtle.down()
    #Circle Color
    turtle.color(random_colorC,random_colorC)
    turtle.pensize( circle_line_width )
    turtle.begin_fill()
    #Circle Drawing
    turtle.circle(radius)
    turtle.end_fill()

num_of_loops = num_of_loops + 1


turtle.done
