# Done by BRINI, Kamil Bilal Valentin SID:2759891
import turtle

turtle.setup(800,600)    # Set the width and height be 800 x 600

number_of_divisions = 8  # The number of subdivisions around the centre
turtle_width = 3         # The width of the turtles

# Don't show the animation
turtle.tracer(False)

# Draw the background lines

backgroundTurtle = turtle.Turtle()

backgroundTurtle.width(1)

backgroundTurtle.down()
backgroundTurtle.color("gray88") # Draw the centered line
for i in range(number_of_divisions):
    backgroundTurtle.forward(500)
    backgroundTurtle.backward(500)
    backgroundTurtle.left(360 / number_of_divisions)

backgroundTurtle.up()

# Show the instructions
backgroundTurtle.color("purple")
backgroundTurtle.goto(-turtle.window_width()/2+50, 100)
backgroundTurtle.write("""s - change a colour for one of the colour buttons
m - all 8 drawing turtles go to middle
c - clear all drawings made by the 8 drawing turtles
""", font=("Arial", 14, "normal"))

backgroundTurtle.hideturtle()

# Set up a turtle for handling message on the turtle screen
messageTurtle = turtle.Turtle()
# This sets the colour of the text to red
messageTurtle.color("red")
# We do not want it to show/draw anything, except the message text
messageTurtle.up() 
# Set it the be at center, near the colour selections
messageTurtle.goto(0, -200)
# We do not want to show it on the screen
messageTurtle.hideturtle()

# Part 2 Preparing the drawing turtles

# The drawing turtles are put in a list
allDrawingTurtles = [] 


# Part 2.1 Add the 8 turtles in the list
# Please finish this part
for _ in range(number_of_divisions):
    new_turtles = turtle.Turtle()
    allDrawingTurtles.append(new_turtles)
    new_turtles.speed(0)
    new_turtles.width(turtle_width)
    new_turtles.hideturtle()

print(len(allDrawingTurtles))

# Part 2.2 Set up the first turtle for drawing
# Please finish this part
dragTurtle = allDrawingTurtles[0]
dragTurtle.shape("circle")
dragTurtle.shapesize(2)
dragTurtle.showturtle()


# Part 3 Preparing the basic drawing system
# Set up the ondrag event
# Please finish this part
def draw(x, y):
    dragTurtle.ondrag(None) # Disable the event
    turtle.tracer(False)  # To pause the update of screen
    messageTurtle.clear() # Added in Part 5.1 for clearing the message from messageTurtle
    
    dragTurtle.goto(x, y)
    
    x_transform = [1, 1, -1, -1, 1, 1, -1, -1] # This represents + + - - + + - -
    y_transform = [1, -1, 1, -1, 1, -1, 1, -1] # This represents + - + - + - + -
    
    for i in range(1, number_of_divisions):
        if i<4:
            new_x = x * x_transform[i] # x with sign change
            new_y = y * y_transform[i] # y with sign change
        else:
            new_x = y * y_transform[i] # Note that we assign y as new x
            new_y = x * x_transform[i] # Note that we assign x as new y

        allDrawingTurtles[i].goto(new_x, new_y)
    turtle.tracer(True)  # To update the screen
    dragTurtle.ondrag(draw) # Enable the event

dragTurtle.ondrag(draw)


# Part 5.2 clear all drawings made by the 8 drawing turtles
def clearDrawing():
    # Please finish this part
    for drawingTurtle in allDrawingTurtles:
        drawingTurtle.clear()
        turtle.tracer(False)  # To pause the update of screen
    messageTurtle.clear() # clear the previous message
    messageTurtle.write("The screen is cleared", \
                       align="center", font=("Arial", 14, "normal"))
    turtle.tracer(True)  # To update the screen
turtle.onkeypress(clearDrawing, 'c')

# Part 5.3 all 8 drawing turtles go to middle
def goToMiddle():
    # Please finish this part
    for drawingTurtle in allDrawingTurtles:
        drawingTurtle.up()
        drawingTurtle.home()
        drawingTurtle.down()
        turtle.tracer(False)  # To pause the update of screen
    messageTurtle.clear() # clear the previous message
    messageTurtle.write("All 8 turtles returned to middle", \
                       align="center", font=("Arial", 14, "normal"))    
    turtle.tracer(True)  # To update the screen

turtle.onkeypress(goToMiddle, 'm')


# Part 4 handling the colour selection
# Make the colour selection turtles
# Here is the list of colours
colours = ["black", "orange red", "lawn green", "medium purple", "light sky blue", "orchid", "gold"]

# Part 4.2 Set up the onclick event
# Please finish this part
def handleColourChange(x, y):
    if x<= -130:
        for thisturtle in range(len(allDrawingTurtles)):
            allDrawingTurtles[thisturtle].color(colours[0])
    elif x<= -80:
        for thisturtle in range(len(allDrawingTurtles)):
            allDrawingTurtles[thisturtle].color(colours[1])
    elif x<= -30:
        for thisturtle in range(len(allDrawingTurtles)):
            allDrawingTurtles[thisturtle].color(colours[2])
    elif x<= 20:
        for thisturtle in range(len(allDrawingTurtles)):
            allDrawingTurtles[thisturtle].color(colours[3])
    elif x<= 70:
        for thisturtle in range(len(allDrawingTurtles)):
            allDrawingTurtles[thisturtle].color(colours[4])
    elif x<= 120:
        for thisturtle in range(len(allDrawingTurtles)):
            allDrawingTurtles[thisturtle].color(colours[5])
    elif x<= 170:
        for thisturtle in range(len(allDrawingTurtles)):
            allDrawingTurtles[thisturtle].color(colours[6])

# Part 5.4 change a colour in the colour selection
def changeColour():
    # Please finish this part
    indexInput = str(turtle.textinput("Change color", "Please type the index number for the turtle: (0-6)"))

    while int(indexInput) not in range (0,7):
        indexInput= str(turtle.textinput("Change color", "Please type a correct index number"))

    if indexInput != None:
        NewColor = turtle.textinput( "Change color","Please type the color you want to use e.g. LightBlue2:" )
        if NewColor != None:
            colours[int(indexInput)] = str(NewColor)
            colourSelectionTurtles = []
            turtle.tracer(False)
            for i in range(len(colours)):
                t = turtle.Turtle()
                t.shape("square")
                t.shapesize(2)
                t.up()
                t.color(colours[i])
                t.goto(-150+50*i, -250)
                t.onclick(handleColourChange)
                colourSelectionTurtles.append(t)
            turtle.tracer(True)
            turtle.listen()
            messageTurtle.clear()
            messageTurtle.write("The colour for that button has been changed, click on the button to use it", \
                           align="center", font=("Arial", 14, "normal"))    

turtle.onkeypress(changeColour, 's')
turtle.listen()

# Part 4.1 Make the colour selection turtles
# Please finish this part
colourSelectionTurtles = []
for i in range(len(colours)):
    t = turtle.Turtle()
    t.shape("square")
    t.shapesize(2)
    t.up()
    t.color(colours[i])
    t.goto(-150+50*i, -250)
    t.onclick(handleColourChange)
    colourSelectionTurtles.append(t)

turtle.tracer(True)
turtle.listen()

turtle.done()

