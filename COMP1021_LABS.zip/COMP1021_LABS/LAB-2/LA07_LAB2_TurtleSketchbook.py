
# COMP1021 Lab 2 Python sketchbook

import turtle       # Import the turtle module for the program

turtle.width(4)
turtle.speed(10)

print("Welcome to the Python sketchbook!")

##### While loop to repeat the main menu

fillcolor = "none"

# Initialize the option to empty in order to enter the while loop

option = ""

while option != "q": # While the option is not "q"
    print()
    print("Please choose one of the following options:")
    print()
    print("m - Move the turtle")
    print("t - Rotate the turtle")
    print("l - Draw a line")
    print("r - Draw a rectangle")
    print("c - Draw a circle")
    print("p - Change the pen colour of the turtle")
    print("f - Change the fill colour of the turtle")
    print("g - Draw a generated flower")
    print("e - Draw a generated explosion")
    print("a - Draw the author's information")
    print("q - Quit the program")
    print()

    option = input("Please input your option: ")


    
    ##### Handle the move option
    if option == "m":
        print()

        # Ask the user for the x and y location
        x = input("Please enter the x location: ")
        x = int(x)
        y = input("Please enter the y location: ")
        y = int(y)

        # Move the turtle without drawing anything
        turtle.up()
        turtle.goto(x, y)
        turtle.down()



    ##### Handle the rotate option
    if option == "t":
        print()
        
        #
        # Please put your code here
        #
        
        # Ask for the rotation angle
        x = input("Please enter how many degrees the turtle must turn to the left: ")
        x = int(x)
        
        # Turn the turtle of x degrees to the left
        turtle.left(x)



    ##### Handle the line option
    if option == "l":
        print()

        # Ask the user for the x and y location
        x = input("Please enter the x location: ")
        x = int(x)
        y = input("Please enter the y location: ")
        y = int(y)

        # Move the turtle and draw a line
        turtle.goto(x, y)
        


    ##### Handle the rectangle option
    if option == "r":
        print()

        #
        # Please put your code here
        #
        
        # Ask the user to input the length and height of the rectangle
        x = input("Please choose a width: ")
        x = int(x)
        y = input("Please choose a height: ")
        y = int(y)

        # If statement - fill
        if fillcolor != "none":
            turtle.begin_fill()

            # Draw the rectangle
            turtle.down()
            turtle.forward(x)
            turtle.left(90)
            turtle.forward(y)
            turtle.left(90)
            turtle.forward(x)
            turtle.left(90)
            turtle.forward(y)
            turtle.left(90)
            turtle.up()
            turtle.end_fill()
        else:
            turtle.down()
            turtle.forward(x)
            turtle.left(90)
            turtle.forward(y)
            turtle.left(90)
            turtle.forward(x)
            turtle.left(90)
            turtle.forward(y)
            turtle.left(90)
            turtle.up()
        


    ##### Handle the circle option
    if option == "c":
        print()

        #
        # Please put your code here
        #
        
        # Ask the user for the radius
        x = input("Please choose a radius: ")
        x = int(x)

        # If statement - fill
        if fillcolor != "none":
            turtle.begin_fill()

            #Draw a circle
            turtle.down()
            turtle.circle(x)
            turtle.up()
            turtle.end_fill()
        else:
            turtle.down()
            turtle.circle(x)
            turtle.up()


            
    ##### Handle the pen colour option
    if option == "p":
        print()

        #
        # Please put your code here
        #
        
        # Ask for a pen color
        pen_color = input("Please choose a pen color: ")

        #Change the color
        turtle.pencolor(pen_color)



    ##### Handle the fill colour option
    if option == "f":
        print()

        #
        # Please put your code here
        #
        
        # Ask for a color filling
        fillcolor = input("Please choose a fill color (type none to clear the color): ")

        #Change the colour
        if fillcolor != "none":
            turtle.fillcolor(fillcolor)



    ##### Handle the generated flower option
    if option == "g":
        print()

        #
        # Please put your code here
        #
        
        # Ask the user for the radius
        radius = input("Please choose a radius for the flower petal: ")
        radius = int(radius)

        # Draw the flower
        if fillcolor != "none":
            turtle.begin_fill()
        for j in range (20):
            for i in range (4):
                turtle.circle(radius, 180)
                turtle.left(90)
            turtle.left(18)
        if fillcolor != "none":
            turtle.end_fill()



    ##### Handle the explosion option
    if option == "e":
        print()

        #
        # Please put your code here
        #
        
        # Ask the user for the size
        size = input("Please enter the size of the explosion (>150): ")
        size = int(size)

        for thiscolor in ["MediumPurple", "OrangeRed", "goldenRod", "yellow"]:
            for i in range (1,5):
                newColor = thiscolor + str(i)
                turtle.color(newColor)
                turtle.dot(size)
                size = size - 10



    ##### Handle the move option
    if option == "a":
        print()

        # draw 9
        turtle.color("red", "orange")
        turtle.begin_fill()
        for i in range (6):
            turtle.down()
            turtle.circle(15)
            turtle.up()
            turtle.left(90)
            turtle.forward(35)
            turtle.right(90)
        turtle.left(180)
        turtle.down()
        turtle.end_fill()

        turtle.color("red", "orange")
        turtle.begin_fill()
        turtle.up()
        turtle.goto(-50,220)
        turtle.down()
        turtle.circle(60)
        turtle.end_fill()

        
        # Repositioning
        turtle.up()
        turtle.goto(60,0)
        turtle.left(180)

        # draw 1
        turtle.color("red", "orange")
        turtle.begin_fill()
        for i in range (6):    
            turtle.down()
            turtle.circle(15)
            turtle.up()
            turtle.left(90)
            turtle.forward(35)
            turtle.right(90)
        turtle.end_fill()


            
turtle.done()
