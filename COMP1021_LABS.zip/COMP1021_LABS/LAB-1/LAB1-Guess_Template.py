import random               # Import the 'random' library

target = 0                  # We will store the number to be guessed here
finished = False            # This is true if the game has finished
guess_input_text = ""       # We will store text in here
guess_input = 0             # We will store a number in here
count = 0                   # We make a variable used to count the guesses

# Generate a new integer random number
target = random.randint(1,100)
print("I am thingking of a number. What number am I thinking of?")
# Do the main game loop
while not finished:
    # Get the user's guess
    guess_input_text = input("Please enter a number between 1 and 100: ")
    guess_input = int(guess_input_text)
    count = count + 1

    # Check the user's guess
    if guess_input < 1 or guess_input > 100:
        print("Your number is out of range.")
    elif guess_input > target:
        print("The number is too high, try again: ")
    elif guess_input < target:
        print("The number is too low, try again: ")
    else:
        finished = True

# At this point, the game is finished
print("You got it! My number is: " + str(target)+".")
print("It took you "+str(count)+" guesses to get my number.")
