import random               # Import the 'random' library
import turtle               #We import Turtle Graphics

target = 0                  # We will store the number to be guessed here
finished = False            # This is true if the game has finished
guess_input_text = ""       # We will store text in here
guess_input = 0             # We will store a number in here
count = 0                   # We make a variable used to count the guesses
xposition = -65
yposition = 200


# Generate a new integer random number
target = random.randint(1,100)
turtle.up()
turtle.goto(xposition, yposition)
turtle.write("I am thingking of a number. What number am I thinking of?", font=("Arial", 10, "bold"))
yposition = yposition - 40

# Do the main game loop
while not finished:

    # Get the user's guess
    guess_input_text = turtle.textinput("Guessing Game","Please enter a number between 1 and 100:")
    guess_input = int(guess_input_text)
    count = count + 1

    # Check the user's guess
    if guess_input < 1 or guess_input > 100:
        turtle.goto(xposition, yposition)
        turtle.write("Your number is out of range, try again.", font=("Arial", 10, "bold"))
        yposition = yposition - 40

    elif guess_input > target:
        turtle.goto(xposition, yposition)
        turtle.write("The number is too high, try again.", font=("Arial", 10, "bold"))
        yposition = yposition - 40

    elif guess_input < target:
        turtle.goto(xposition, yposition)
        turtle.write("The number is too low, try again.", font=("Arial", 10, "bold"))
        yposition = yposition - 40

    else:
        finished = True


# At this point, the game is finished
turtle.goto(xposition, yposition)
turtle.write("You got it! My number is: " + str(target)+".", font=("Arial", 20, "bold"))
yposition = yposition - 40
turtle.goto(xposition, yposition)
turtle.write("It took you " + str(count) + " guesses to get my number.", font=("Arial", 20, "bold"))
yposition = yposition - 40
turtle.down()

turtle.done()
