/**
 * This class contains the information of a dim sum dish
 */

public class DimSum
{
    //
    // Task 1 - create the attributes
    //
    // The name of the dim sum
    String name;
    // The price of the dim sum
    float price;
    // The quantity ordered    
    int quantity = 0;
  
    
    // Constructor of the class
    public DimSum(String name, float price) {
        //
        // Task 1 - Initialize the attributes of the dim sum
        this.name = name;
        this.price = price;
        //
    }
   
    
    // Return the name of the dim sum
    public String getName() {
        //
        // Task 1 - Return the name of the dim sum
        //
        return name;
    }
    
    // Return the price of the dim sum
    public float getPrice() {
        //
        // Task 1 - Return the price of the dim sum
        //
        return price;
    }
    
    // Return the quantity ordered
    public int getQuantity() {
        //
        // Task 1 - Return the quantity of the dim sum
        // 
        return quantity;
    }
    
    // Order this dim sum dish
    public void order(int orderquantity) {
        //
        // Task 1 - Increase the quantity ordered
        //
        this.quantity = quantity + orderquantity;
    }
}
