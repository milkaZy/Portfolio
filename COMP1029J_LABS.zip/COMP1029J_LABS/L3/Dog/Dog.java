    /**
     * This is the definition of the Dog class.
     */
    public class Dog
    {    
        // This is the bark method
        void bark() {
            int[][] board = new int[5][6];
            int row, col;

            for (row = 0; row < 5; row++) {
                for (col = 0; col < 6; col++) {
                    if (row % 2 == col % 2)
                        board[row][col] = 1;
                    else
                        board[row][col] = 0;
                    }
                }   
            }
}