public class A {
    int x;
    public A(int number) {
        x = number;
    }
    public void showme() {
        println("x = " + x);
    }
}