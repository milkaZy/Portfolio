public class B extends A {
    public B(int x) {
        super(x * 2);
    }
    public void showme() {
        println("x is equal to " + x);
    }
    
    A a = new A(10);
    B b = new B(5);

    a.showme();
    b.showme();
}